#include "scf.hpp"
//
//
//
void algorithm::scf::update_fock_matrix(array &f_matrix, array &h_matrix, array &p_matrix, array &two_electrons_interaction)
{
    double energy = 0.0;
    f_matrix.set_all(0.0);
    for(unsigned int i = 1; i <= h_matrix.size_of_row(); i++)
    {
        for(unsigned int j = 1; j <= h_matrix.size_of_column(); j++)
        {
            for(unsigned int m = 1; m <= h_matrix.size_of_row(); m++)
            {
                for(unsigned int n = 1; n <= h_matrix.size_of_column(); n++)
                {
                    energy += p_matrix.get(m, n)
                            * (two_electrons_interaction.get(i, j, n, m) - 0.5*two_electrons_interaction.get(i, m, n, j));
                }
            }
            f_matrix.set(i, j, h_matrix.get(i, j) + energy);
            energy = 0.0;
        }
    }
}
