#include "array.hpp"
//
//
//
void array::save_transpose_to(array &given_array)
{
//  (1) To invoke the GSL gsl_matrix_transpose_memcpy() member to handle 
//      the transposition of the current array and to store in the given one.
    if(is_2d_array && given_array.is_2d_array && (!given_array.is_const_array))
    {
        gsl_matrix_transpose_memcpy(given_array.user_2d_array, user_2d_array); // (1)
    }
}
