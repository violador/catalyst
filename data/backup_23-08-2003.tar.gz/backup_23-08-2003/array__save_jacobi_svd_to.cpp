#include "array.hpp"
//
//
//
void array::save_jacobi_svd_to(array &u_matrix, array &eigenvalues)
{
//  (1) To calculate the SVD using Jacobi's method and the GSL gsl_linalg_SV_decomp_jacobi() member.
    if(is_2d_array)
    {
        gsl_linalg_SV_decomp_jacobi(user_2d_array, u_matrix.user_2d_array, eigenvalues.user_1d_array); // (1)
    }
}
