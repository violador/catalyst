#include "sto3g.hpp"
//
//
//
double lcao_wavefunction::sto3g::exp(const unsigned int &atom_type, const unsigned int &primitive_function)
{
    switch(atom_type)
    {
    case 1:
    {
        switch(primitive_function)
        {
        case 1:  return 3.42525091; break;
        case 2:  return 0.62391373; break;
        case 3:  return 0.16885540; break;
        default: return 0.0; 
        };
    }
    break;
    case 2:
    {
        switch(primitive_function)
        {
        case 1:  return 6.36242139; break;
        case 2:  return 1.15892300; break;
        case 3:  return 0.31364979; break;
        default: return 0.0; 
        };
    }
    break;
    case 8:
    {
        switch(primitive_function)
        {
        case 1:  return 130.7093200; break;
        case 2:  return 23.8088610;  break;
        case 3:  return 6.4436083;   break;
        case 4:  return 5.0331513;   break;
        case 5:  return 1.1695961;   break;
        case 6:  return 0.3803890;   break;
        default: return 0.0; 
        };
    }
    break;
   default: return 0.0; 
   };
}
