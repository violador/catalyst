#include "scf.hpp"
//
//
//
unsigned int algorithm::scf::number_of_iterations() 
{
    return iteration;
}
