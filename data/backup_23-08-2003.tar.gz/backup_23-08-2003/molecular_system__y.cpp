#include "molecular_system.hpp"
//
//
//
double molecular_system::y()
{
    if(system_com_ready)
    {
        return system_com_y;
    }
    else
    {
        get_system_com();
        return system_com_y;
    }
    /*return (atom_positions_ready && (atom > 0) && (atom <= total_atoms)? position_y.get(atom) : 0.0);*/
}
//
//
//
double molecular_system::y(const unsigned int &option, const unsigned int &atom)
{
    switch(option)
    {
    case 1:
    {
        if(atom_positions_ready && (atom > 0) && (atom <= total_atoms))
        {
            return position_y.get(atom);
        }
        else
        {
            return 0.0;
        }
    }
    break; 
    case 2:
    { 
        if(atom_velocities_ready && (atom > 0) && (atom <= total_atoms))
        {
            return velocity_y.get(atom);
        }
        else
        {
            return 0.0;
        }
    }
    break;
    default: return 0.0;
    }
}
