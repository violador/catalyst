#include "array.hpp"
//
//
//
void array::save_to(const std::string &array_filename)
{
    std::ofstream array_file(array_filename.c_str(), std::ios::out | std::ios::binary);
    if(array_file.is_open() && array_file.good())
    {
        array_file.width(7);
        array_file << std::left << sizeof_row;
        array_file.width(7);
        array_file << std::left << sizeof_column;
        #pragma omp for schedule(dynamic)
        for(unsigned int i = 0; i <= (sizeof_row - 1); i++)
        {
            for(unsigned int j = 0; j <= (sizeof_column - 1); j++)
            {
                array_file.precision(MAX_PRECISION);
                array_file.width(MAX_PRECISION + 3);
                array_file << std::left << gsl_matrix_get(user_2d_array, i, j);
            }
        }
        array_file.close();
    }
    else
    {
        std::cout << "ERROR: Was not possible to open the file!" << std::endl;
    }
}
