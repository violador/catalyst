#include "array.hpp"
//
//
//
void array::set_all(const double &value)
{
    if(is_1d_array && created_array && (!deleted_array))
    {
        gsl_vector_set_all(user_1d_array, value);
    }
    else if(is_2d_array && created_array && (!deleted_array))
    {
        gsl_matrix_set_all(user_2d_array, value);
    }
    else if(is_3d_array && created_array && (!deleted_array))
    {
//      To be implemented someday!
    }
    else if(is_4d_array && created_array && (!deleted_array))
    {
//      To be implemented someday!
    }
}
