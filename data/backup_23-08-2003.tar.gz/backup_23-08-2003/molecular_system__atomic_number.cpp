#include "molecular_system.hpp"
//
//
//
double molecular_system::atomic_number(const unsigned int &atom)
{
    if(atom_types_ready && (atom > 0) && (atom <= total_atoms))
    {
        return ((double) atom_type.get(atom));
    }
    else
    {
        return 0.0;
    }
}
