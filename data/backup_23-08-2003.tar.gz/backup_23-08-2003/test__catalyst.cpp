#include "globals.hpp"
#include "settings.hpp"
#include "periodic_table.hpp"
#include "sto3g.hpp"
#include "molecular_system.hpp"
#include "tools.hpp"
#include "array.hpp"
//
//
//
int main(int argc, char* argv[])
{
   settings teste;
   teste.settings::init_log();
   std::string file = "data/pyr.xyz";
   molecular_system HeH(file, teste);
   std::cout << "electronic energy = " << HeH.molecular_system::electronic_energy() << std::endl;
/*
  boost::mpi::environment env(argc, argv);
  boost::mpi::communicator world;
  settings teste(world);
*/
/*

  if (world.boost::mpi::communicator::rank() == 0) {
    std::string msg;
    world.boost::mpi::communicator::recv(1, 1, msg);
    std::cout << "o cpu 1 ta dizendo "  << msg << std::endl;
  } else if(world.boost::mpi::communicator::rank() == 1)
  {
    world.boost::mpi::communicator::send(0, 1, std::string("bye!"));
  }
*/
   return 0;
}
