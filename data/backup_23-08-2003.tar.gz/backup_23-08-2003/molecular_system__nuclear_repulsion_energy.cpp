#include "molecular_system.hpp"
//
//
//
double molecular_system::nuclear_repulsion_energy()
{
    if(nuclear_repulsion_ready)
    {
        return nuclear_repulsion;
    }
    else
    {
        get_nuclear_repulsion();
        return nuclear_repulsion;
    }
}
