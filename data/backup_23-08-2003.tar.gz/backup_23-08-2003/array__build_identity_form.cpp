#include "array.hpp"
//
//
//
void array::build_identity_form()
{
    if(is_2d_array && created_array && (!deleted_array) && (!is_const_array))
    {
        gsl_matrix_set_identity(user_2d_array);
    }
}
