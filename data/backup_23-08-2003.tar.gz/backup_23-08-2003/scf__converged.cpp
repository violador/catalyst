#include "scf.hpp"
//
//
//
bool algorithm::scf::converged() 
{
    return scf_converged;
}
