#include "molecular_system.hpp"
//
//
//
void molecular_system::report_input_reading() 
{
    if(config -> state_of(OUTPUT))                                                                   
    {
        if(config -> logfile_initialized())
        {
            LOGFILE_IS_READY:
            std::string log_filename = config -> filename_of(LOG_FILE);
            std::ofstream log_file(log_filename.c_str(), std::ios::out | std::ios::app); 
            if(log_file.is_open() && log_file.good())                                    
            {
                #define SPACE_LENGTH         3
                #define FIRST_COLUMN_LENGTH  4
                #define SECOND_COLUMN_LENGTH 4
                unsigned int title_bar_length = FIRST_COLUMN_LENGTH 
                                              + SECOND_COLUMN_LENGTH
                                              + SPACE_LENGTH
                                              + 6*(MAX_PRECISION + SPACE_LENGTH)
                                              - (system_name.length() + 4);
//
                log_file << "\n== " << system_name << " "; 
                log_file.width(title_bar_length);
                log_file.fill('=');
                log_file << "\n" << std::endl;
//
                log_file.width(50);
                log_file.fill(' ');
                log_file << "Positions";
//
                log_file.width(38);
                log_file.fill(' ');
                log_file << "Velocities\n";
//
                log_file.width(FIRST_COLUMN_LENGTH + SECOND_COLUMN_LENGTH + SPACE_LENGTH + 6*(MAX_PRECISION + SPACE_LENGTH));
                log_file.fill(' ');
                log_file << "----------------------------------------------------------------------------\n";
//
                log_file.width(FIRST_COLUMN_LENGTH);
                log_file.fill(' ');
                log_file << "Num.";
//
                log_file.width(SECOND_COLUMN_LENGTH + SPACE_LENGTH);
                log_file.fill(' ');
                log_file << "Type";
//
                log_file.width(MAX_PRECISION + SPACE_LENGTH);
                log_file.fill(' ');
                log_file << std::right << "x";
//
                log_file.width(MAX_PRECISION + SPACE_LENGTH);
                log_file.fill(' ');
                log_file << std::right << "y";
//
                log_file.width(MAX_PRECISION + SPACE_LENGTH);
                log_file.fill(' ');
                log_file << std::right << "z";
//
                log_file.width(MAX_PRECISION + SPACE_LENGTH);
                log_file.fill(' ');
                log_file << std::right << "x";
//
                log_file.width(MAX_PRECISION + SPACE_LENGTH);
                log_file.fill(' ');
                log_file << std::right << "y";
//
                log_file.width(MAX_PRECISION + SPACE_LENGTH);
                log_file.fill(' ');
                log_file << std::right << "z\n";
//
                log_file.width(FIRST_COLUMN_LENGTH + SECOND_COLUMN_LENGTH + SPACE_LENGTH + 6*(MAX_PRECISION + SPACE_LENGTH));
                log_file.fill('-');
                log_file << "\n";
//
                periodic_table get;
                #pragma omp for schedule(dynamic)
                for(unsigned int i_atom = 1; i_atom <= total_atoms; i_atom++)
                {
//
                    log_file.fill(' ');
                    log_file.width(FIRST_COLUMN_LENGTH);
                    log_file << std::right << i_atom;
//
                    log_file.width(SECOND_COLUMN_LENGTH + SPACE_LENGTH);
                    log_file.fill(' ');
                    log_file << std::right << get.periodic_table::symbol(type(i_atom));
//
                    log_file.width(MAX_PRECISION + SPACE_LENGTH);
                    log_file.precision(config -> numeric_precision());
                    log_file << std::right << x(POSITION, i_atom);
//
                    log_file.width(MAX_PRECISION + SPACE_LENGTH);
                    log_file.precision(config -> numeric_precision());
                    log_file << std::right << y(POSITION, i_atom);
//
                    log_file.width(MAX_PRECISION + SPACE_LENGTH);
                    log_file.precision(config -> numeric_precision());
                    log_file << std::right << z(POSITION, i_atom);
//
                    log_file.width(MAX_PRECISION + SPACE_LENGTH);
                    log_file.precision(config -> numeric_precision());
                    log_file << std::right << x(VELOCITY, i_atom);
//
                    log_file.width(MAX_PRECISION + SPACE_LENGTH);
                    log_file.precision(config -> numeric_precision());
                    log_file << std::right << y(VELOCITY, i_atom);
//
                    log_file.width(MAX_PRECISION + SPACE_LENGTH);
                    log_file.precision(config -> numeric_precision());
                    log_file << std::right << z(VELOCITY, i_atom) << std::endl;
//
                } // for(i_atom)
                log_file << "\n- Input file               = " << name()
                         << "\n- Total atoms              = " << number_of_atoms()
                         << "\n- Total charge             = " << charge
                         << "\n- Center of mass           = " << "(" << x() << ", " << y() << ", " << z() << ")"
                         << "\n- Nuclear repulsion energy = " << nuclear_repulsion_energy() << " a.u." << std::endl;
                log_file.close();
            }
            else // if(!log_file.is_open() || !log_file.good())
            {
            }
        }
        else // if(!config -> logfile_initialized())
        {
            config -> init_log();
            goto LOGFILE_IS_READY;
        }
    } // !output_mode_on
}
