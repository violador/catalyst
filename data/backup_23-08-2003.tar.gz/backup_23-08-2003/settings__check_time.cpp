#include "settings.hpp"
//
//
//
char* settings::check_time()
{
    time_t current_time = time(0);
//  struct tm *now = localtime(&current_time);
    return ctime(&current_time);
}
