#include "settings.hpp"
#ifdef LINUX
//
// Linux OS only member function to get the total memory and the current memory:
double settings::check_memory(const int option)
{
    struct sysinfo info;
    switch(option)
    {
    case 1:  return info.totalram*info.mem_unit; break;
    case 2:  return info.freeram*info.mem_unit;  break;
    default: return 0; break;
    }
}
#endif
