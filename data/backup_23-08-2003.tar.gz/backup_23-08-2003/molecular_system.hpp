#ifndef __MOLECULAR_SYSTEM_HPP
#define __MOLECULAR_SYSTEM_HPP
#include "globals.hpp"
#include "settings.hpp"
#include "periodic_table.hpp"
#include "sto3g.hpp"
#include "scf.hpp"
#include "tools.hpp"
//
//
//
class molecular_system
{
private:
//
//  Declaring the data members used to store the molecular system properties:
    settings *config;             // A pointer-object to link with any object of settings type.
    unsigned int task_number;     // The number of the current task.
    unsigned int total_electrons; // The total number of electrons.
    unsigned int total_atoms;     // The total number of atoms.
    array atom_type;              // The type of each atom (Z) as a non negative integral type.
    array position_x;             // The atom position in the x axis.
    array position_y;             // The atom position in the y axis.
    array position_z;             // The atom position in the z axis.
    array velocity_x;             // The atom velocity in the x axis.
    array velocity_y;             // The atom velocity in the y axis.
    array velocity_z;             // The atom velocity in the z axis.
    double total_mass;            // The molecular system mass.
    double charge;                // The molecular system charge.
    double nuclear_repulsion;     // The nuclei-nuclei repulsion energy.
    double system_com_x;          // The system's center of mass position in the x axis.
    double system_com_y;          // The system's center of mass position in the y axis.
    double system_com_z;          // The system's center of mass position in the z axis.
    std::string system_name;      // The molecular system name.
    bool ab_initio_ready;         // The ab-initio calculation state. True if it is already done, false otherwise.
    bool system_com_ready;        // The center of mass (COM) calculation state. True if it is already done, false otherwise.
    bool atom_types_ready;        // The atom types reading state. True if it is already done, false otherwise.
    bool atom_positions_ready;    // The atom positions reading state. True if it is already done, false otherwise.
    bool atom_velocities_ready;   // The atom velocities reading state. True if it is already done, false otherwise.
    bool total_atoms_ready;       // The total number of atoms calculation state. True if it is already done, false otherwise.
    bool nuclear_repulsion_ready; // The nuclear repulsion calculation state. True if it is already done, false otherwise.
    algorithm::scf *wavefunction; // A pointer-object to link with any object of algorithm::scf type.
//
//  get_total_atoms(): To count the number of lines in a given input file,
//                     i.e. the number of atoms.
    unsigned int get_total_atoms(std::string input_filename); 
//
//  read_geometry(): To read the molecular system's geometry from a given ifstream file.
    void read_input_file(const std::string &input_filename); 
//
//  get_system_com(): To calculate the system center of mass.
    void get_system_com();
//
//  get_nuclear_repulsion(): To calculate the nuclear repulsion energy.
    void get_nuclear_repulsion();
//
//  report_input_reading(): To report the inputfile reading in the logfile.
    void report_input_reading();
//
//  get_wavefunction(): To start the calculation of all ab-initio datas. Caution: This function may be the most expensive
//                      part of the entire runtime. 
    void get_wavefunction(unsigned int theory_level);
//
//
public:
//
//
    static const int class_id = 5127;
//
//  Declaring the class constructor:
    molecular_system(const std::string &input_filename, const unsigned int &given_task = DEFAULT_TASK_NUMBER);
//
//  Declaring the class constructor:
    molecular_system(const std::string &input_filename, settings &runtime_setup, const unsigned int &given_task = DEFAULT_TASK_NUMBER);
//
//  number_of_atoms(): To return the total number of atoms.
    unsigned int number_of_atoms();
//
//  x(): To return the COM position in the x axis.
    double x();
//
//  x(): To return the position in the x axis of the given atom in a given option.
    double x(const unsigned int &option, const unsigned int &atom);
//
//  y(): To return the COM position in the y axis.
    double y();
//
//  y(): To return the position in the y axis of the given atom in a given option.
    double y(const unsigned int &option, const unsigned int &atom);
//
//  z(): To return the COM position in the z axis.
    double z();
//
//  z(): To return the position in the z axis of the given atom in a given option.
    double z(const unsigned int &option, const unsigned int &atom);
//
//  Defining some alias for the x(), y() and z() members options:
    #define POSITION 1
    #define VELOCITY 2
//
//  mass(): To return the mass of the given atom.
    double mass(const unsigned &atom);
//
//  mass(): To return the mass of the current molecular system.
    double mass();
//
//  interatomic_distance(): To return the distance between two given atoms.
    double interatomic_distance(const unsigned int &first_atom, const unsigned int &second_atom);
//
//  atomic_number(): To return the atomic number (Z) of the given atom.
    double atomic_number(const unsigned int &atom);
//
//  type(): To return the type of a given atom (Z) in a non negative integral type.
    unsigned int type(const unsigned int &atom);
//
//  density(): To return the value of the density matrix for two given atoms.
    double density(const unsigned int &first_atom, const unsigned int &second_atom);
//
//  nuclear_repulsion_energy(): To return the nuclear repulsion energy.
    double nuclear_repulsion_energy();
//
//  electronic_energy(): To return the converged energy from any SCF routine.
    double electronic_energy();
//
//  name(): To return the current system's name if any.
    std::string name()
    {
        return system_name;
    };
};
#endif
