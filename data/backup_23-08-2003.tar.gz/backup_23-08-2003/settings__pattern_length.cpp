#include <iostream>
#include <string>
#include "settings.hpp"
//
//
// Defining an auxiliar member function to help the others:
unsigned int settings::pattern_length(const std::string pattern)
{
//  It will return the string lenght of a given pattern.
    return pattern.length();
}
