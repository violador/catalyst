#include "array.hpp"
//
//
//
void array::create_array(const unsigned int local_1st_layer_size,
                         const unsigned int local_2nd_layer_size,
                         const unsigned int local_row_size,
                         const unsigned int local_column_size)
{
    tools id;
    if((local_1st_layer_size > 0) && (local_2nd_layer_size == 0))
    {
        array_id         = (unsigned short int) id.generate_integral_type();
        is_1d_array      = true;
        is_2d_array      = false;
        is_3d_array      = false;
        is_4d_array      = false;
        sizeof_row       = local_1st_layer_size;
        sizeof_column    = 0;
        sizeof_1st_layer = 0;
        sizeof_2nd_layer = 0;
        sizeof_3rd_layer = 0;
        user_1d_array    = gsl_vector_calloc(sizeof_row);
        is_const_array   = false;
        is_square_array  = false;
        created_array    = true;
        deleted_array    = false;
        array_name       = "Unknown array";
    }
    else if((local_1st_layer_size > 0) && (local_2nd_layer_size > 0) && (local_row_size == 0))
    {
        array_id         = (unsigned short int) id.generate_integral_type();
        is_1d_array      = false;
        is_2d_array      = true;
        is_3d_array      = false;
        is_4d_array      = false;
        sizeof_row       = local_1st_layer_size;
        sizeof_column    = local_2nd_layer_size;
        sizeof_1st_layer = 0;
        sizeof_2nd_layer = 0;
        sizeof_3rd_layer = 0;
        user_2d_array    = gsl_matrix_calloc(sizeof_row, sizeof_column);
        is_const_array   = false;
        is_square_array  = (sizeof_row == sizeof_column? true : false);
        created_array    = true;
        deleted_array    = false;
        array_name       = "Unknown array";
    }
    else if((local_1st_layer_size > 0) && (local_2nd_layer_size > 0) && (local_row_size > 0) && (local_column_size == 0))
    {
        array_id         = (unsigned short int) id.generate_integral_type();
        is_1d_array      = false;
        is_2d_array      = false;
        is_3d_array      = true;
        is_4d_array      = false;
        sizeof_row       = local_row_size;
        sizeof_column    = local_column_size;
        sizeof_1st_layer = local_1st_layer_size;
        sizeof_2nd_layer = 0;
        sizeof_3rd_layer = 0;
        user_3d_array    = new double **[sizeof_1st_layer];
        for(unsigned int i = 0; i < sizeof_1st_layer; ++i)
        {
            user_3d_array[i] = new double *[sizeof_row];
            for(unsigned int j = 0; j < sizeof_row; ++j)
            {	
                user_3d_array[i][j] = new double [sizeof_column];
            }
        }
        is_const_array  = false;
        is_square_array = false;
        created_array   = true;
        deleted_array   = false;
        array_name      = "Unknown array";
    }
    else
    {
        array_id         = (unsigned short int) id.generate_integral_type();
        is_1d_array      = false;
        is_2d_array      = false;
        is_3d_array      = false;
        is_4d_array      = true;
        sizeof_row       = local_row_size;
        sizeof_column    = local_column_size;
        sizeof_1st_layer = local_1st_layer_size;
        sizeof_2nd_layer = local_2nd_layer_size;
        sizeof_3rd_layer = 0;
        user_4d_array    = new double ***[sizeof_1st_layer];
        for(unsigned int i = 0; i < sizeof_1st_layer; ++i)
        {
            user_4d_array[i] = new double **[sizeof_2nd_layer];
            for(unsigned int j = 0; j < sizeof_2nd_layer; ++j)
            {
                user_4d_array[i][j] = new double *[sizeof_row];
                for(unsigned int m = 0; m < sizeof_row; ++m)
                {
                    user_4d_array[i][j][m] = new double[sizeof_column];
                }
            }
        }
        is_const_array  = false;
        is_square_array = false;
        created_array   = true;
        deleted_array   = false;
        array_name      = "Unknown array";
    }    
}
