#include "molecular_system.hpp"
//
//
//
unsigned int molecular_system::number_of_atoms()
{
    return (total_atoms_ready? total_atoms : 0);
}
