#include "array.hpp"
//
//
//
double array::get(const unsigned int &i)
{
    if(is_1d_array && created_array && (!deleted_array))
    {
        return (((i > 0) && (i <= sizeof_row))? gsl_vector_get(user_1d_array, i - 1) : 0.0);
    }
    else
    {
        return 0.0;
    }
}
//
//
//
double array::get(const unsigned int &i, const unsigned int &j)
{
    if(is_2d_array && created_array && (!deleted_array))
    {
        if((i > 0) && (j > 0) && (i <= sizeof_row) && (j <= sizeof_column))
        { 
            return gsl_matrix_get(user_2d_array, i - 1, j - 1); 
        }
        else
        {
            return 0.0;
        }
    }
    else
    {
        return 0.0;
    }
}
//
//
//
double array::get(const unsigned int &i, const unsigned int &j, const unsigned int &m)
{
    if(is_3d_array && created_array && (!deleted_array))
    {
        if((i > 0) && 
           (j > 0) && 
           (m > 0) && 
           (i <= sizeof_1st_layer) && 
           (j <= sizeof_row)       && 
           (m <= sizeof_column))
        {
            return user_3d_array[i - 1][j - 1][m - 1];
        }
        else
        {
            return 0.0;
        }
    }
    else
    {
        return 0.0;
    }
}
//
//
//
double array::get(const unsigned int &i, const unsigned int &j, const unsigned int &m, const unsigned int &n)
{ 
    if(is_4d_array && created_array && (!deleted_array))
    {
        if((i > 0) && 
           (j > 0) && 
           (m > 0) && 
           (n > 0) && 
           (i <= sizeof_1st_layer) && 
           (j <= sizeof_2nd_layer) && 
           (m <= sizeof_row)       && 
           (n <= sizeof_column))
        {
            return user_4d_array[i - 1][j - 1][m - 1][n - 1];
        }
        else
        {
            return 0.0;
        }
    }
    else
    {
        return 0.0;
    }
}
