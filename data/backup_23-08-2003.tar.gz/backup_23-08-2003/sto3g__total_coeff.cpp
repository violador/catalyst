#include "sto3g.hpp"
//
//
//
unsigned int lcao_wavefunction::sto3g::total_coeff(const unsigned int &atom_type)
{
    switch(atom_type)
    {
    case 1: return 3; break;
    case 2: return 0; break;
    case 8: return 6; break;
    default: return 0; 
    };
}
