Provaveis problemas com MPI após instalar a Boost.MPI:
 - /usr/lib/libboost_serialization.so.1.54.0
 - 
