#include "array.hpp"
//
//
//
void array::set(const unsigned int &i, const double &value)
{
    if(is_1d_array && created_array && (!deleted_array) && (!is_const_array))
    {
        if((i > 0) && (i <= sizeof_row))
        {
            gsl_vector_set(user_1d_array, i - 1, value);
        }
    }
}
//
//
//
void array::set(const unsigned int &i, const unsigned int &j, const double &value)
{
    if(is_2d_array && created_array && (!deleted_array) && (!is_const_array))
    {
        if((i > 0) && (j > 0) && (i <= sizeof_row) && (j <= sizeof_column))
        {
            gsl_matrix_set(user_2d_array, i - 1, j - 1, value);
        }
    }
}
//
//
//
void array::set(const unsigned int &i, const unsigned int &j, const unsigned int &m, const double &value)
{
    if(is_3d_array && created_array && (!deleted_array) && (!is_const_array))
    {
        if((i > 0) && 
           (j > 0) && 
           (m > 0) && 
           (i <= sizeof_1st_layer) && 
           (j <= sizeof_row)       && 
           (m <= sizeof_column))
        {
            user_3d_array[i - 1][j - 1][m - 1] = value;
        }
    }
}
//
//
//
void array::set(const unsigned int &i, 
                const unsigned int &j, 
                const unsigned int &m, 
                const unsigned int &n, 
                const double &value)
{
    if(is_4d_array && created_array && (!deleted_array) && (!is_const_array))
    {
        if((i > 0) && 
           (j > 0) && 
           (m > 0) && 
           (n > 0) &&
           (i <= sizeof_1st_layer) && 
           (j <= sizeof_2nd_layer) && 
           (m <= sizeof_row)       && 
           (n <= sizeof_column))
        {
            user_4d_array[i - 1][j - 1][m - 1][n - 1] = value;
        }
    }
}
