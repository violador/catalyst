#ifndef __ARRAY_HPP
#define __ARRAY_HPP
#include "globals.hpp"
#include "tools.hpp"
//
//
//
struct array
{
protected:
//
//  Declaring the data members: 
    unsigned int sizeof_row;       // The size of row. 
    unsigned int sizeof_column;    // The size of column.
    unsigned int sizeof_1st_layer; // The size of first layer.
    unsigned int sizeof_2nd_layer; // The size of second layer.
    unsigned int sizeof_3rd_layer; // The size of third layer.
    unsigned int array_id;         // To tag the current array.
    bool is_1d_array;              // True, if it is a 1D array, false otherwise.
    bool is_2d_array;              // True, if it is a 2D array, false otherwise.
    bool is_3d_array;              // True, if it is a 3D array, false otherwise.
    bool is_4d_array;              // True, if it is a 4D array, false otherwise.
    bool is_const_array;           // True, if it is a constant array, false otherwise.
    bool is_square_array;          // True, if it is a square array, false otherwise.
    bool created_array;            // True, if it was created already by constructors or create_array(), false otherwise.
    bool deleted_array;            // True, if it was deleted already by delete_array(), false otherwise.
    bool print_by_lines;           // True, if the current array must be printed line by line.
    gsl_vector *user_1d_array;     // The current user's 1D array.
    gsl_matrix *user_2d_array;     // The current user's 2D array
    double   ***user_3d_array;     // The current user's 3D array
    double  ****user_4d_array;     // The current user's 4D array
    std::string array_name;        // The array name, if any.
//
//
public:
//
//
    static const int struct_id = 2431;
//
//  Declaring the class constructor:
    array();
//
//  Declaring the class constructor:
    array(const unsigned int &local_row_size);
//
//  Declaring the class constructor:
    array(const unsigned int &local_row_size, const unsigned int &local_column_size);
//
//  Declaring the class constructor:
    array(const unsigned int &local_layer_size, const unsigned int &local_row_size, const unsigned int &local_column_size);
//
//  Declaring the class constructor:
    array(const unsigned int &local_1st_layer_size, 
          const unsigned int &local_2nd_layer_size, 
          const unsigned int &local_row_size, 
          const unsigned int &local_column_size);
//
// create_array(): To allocate the memory for the requested size.
   void create_array(const unsigned int local_1st_layer_size = 0,
                     const unsigned int local_2nd_layer_size = 0,
                     const unsigned int local_row_size = 0,
                     const unsigned int local_column_size = 0);
//
//  delete_array(): Frees the allocated memory of the current array.
    void delete_array();
//
//  size_of_row(): To return the current size of row.
    unsigned int size_of_row()
    {
        return sizeof_row;
    };
//
//  size_of_column(): To return the current size of column.
    unsigned int size_of_column()
    {
        return sizeof_column;
    };
//
//  size_of_1st_layer(): To return the current size of layer.
    unsigned int size_of_1st_layer()
    {
        return sizeof_1st_layer;
    };
//
//  size_of_2nd_layer(): To return the current size of layer.
    unsigned int size_of_2nd_layer()
    {
        return sizeof_2nd_layer;
    };
//
//  set_constant(): To set up the current array as constant (change the behavior of some functions).
    void set_constant()
    {
        is_const_array = true;
    };
//
//  unset_constant(): To set up the current array as non constant (change the behavior of some functions).
    void unset_constant()
    {
        is_const_array = false;
    };
//
//  is_constant(): To return true if the current array is constant and false otherwise.
    bool is_constant()
    {
        return is_const_array;
    };
//
//  check_array_id(): To check the identifier number of the current array.
    unsigned int check_array_id()
    {
        return array_id;
    };
//
//  check_if(): To check if the current array is positive, negative or null.
    bool check_if(const unsigned int &option);
//
//  Defining some alias for the check_if() member function options:
    #define IS_POSITIVE 1
    #define IS_NEGATIVE 2
    #define IS_NULL     3
//
//
    bool check_if_column_is(const unsigned int &option, const unsigned int &j);
//
// 
    #define POSITIVE 1
    #define NEGATIVE 2
//
//  set_all(): To fill up the array with the given value.
    void set_all(const double &value);
//
//  get(): To return the current value in the given position.
    double get(const unsigned int &i);
//
//  set(): To set the given value in the given position.
    void set(const unsigned int &i, const double &value);
//
//  get(): To return the current value in the given position.
    double get(const unsigned int &i, const unsigned int &j);
//
//  set(): To set the given value in the given position.
    void set(const unsigned int &i, const unsigned int &j, const double &value);
//
//  get(): To return the current value in the given position.
    double get(const unsigned int &i, const unsigned int &j, const unsigned int &m);
//
//  set(): To set the given value in the given position.
    void set(const unsigned int &i, const unsigned int &j, const unsigned int &m, const double &value);
//
//  get(): To return the current value in the given position.
    double get(const unsigned int &i, const unsigned int &j, const unsigned int &m, const unsigned int &n);
//
//  set(): To set the given value in the given position.
    void set(const unsigned int &i, 
             const unsigned int &j, 
             const unsigned int &m, 
             const unsigned int &n, 
             const double &value);
//
//  set_name(): To set a name for the current array.
    void set_name(const std::string &given_name)
    {
        array_name = given_name;
    };
//
//  get_name(): To return the name of the current array.
    std::string get_name()
    {
        return array_name;
    };
//
//
    unsigned int get_min_index()
    {
        return gsl_vector_min_index(user_1d_array) + 1;
    };
//
//
    unsigned int get_max_index()
    { 
        return gsl_vector_max_index(user_1d_array) + 1;
    };
//
//  copy_to(): To copy the content from the current array to the given one.
    void copy_to(array &given_array);
//
//  multiply_by(): To multiply the current array (on the left) by the given one 
//                 on the right (1D and 2D arrays only). The current array will 
//                 be replaced by the product result.
//                 
    void multiply_by(array &given_array);
//
//  save_transpose_to(): To save the transpose of the current array in the given one (2D
//                       array only).
    void save_transpose_to(array &given_array);
//
//  transposed_multiply_by(): To transpose the current array and multiply by the given one.
//                            The current array will be replaced by the product result (2D
//                            array only).
    void transposed_multiply_by(array &given_array);
//
//  multiply_by_transpose_of(): To multiply by the given transposed array. The current array
//                              will be replaced by the product result (2D array only).
    void multiply_by_transpose_of(array &given_array);
//
//  add_to(): To add the current array to the given one. The given array will be replaced.
    void add_to(array &given_array);
//
//  save_jacobi_svd_to(): To calculate the singular value decompositions (SVD) using the
//                        Jacobi's method. And to store the transformation matrix and the
//                        eigenvalues in the given arrays. The current matrix will be replaced
//                        by its transformation.
    void save_jacobi_svd_to(array &u_matrix, array &eigenvalues);
//
//  save_eigens_to(): To calculate the eigenvalues and eigenvectors of the current matrix and to
//                    store in the given arrays. The current matrix keeps unchanged.
    void save_eigens_to(array &eigenvalues, array &eigenvectors);
//
//  orthonormalize(): To use the current array to build a transformation array and to orthonormalize 
//                    the given one using the canonical orthonormalization. The current array will
//                    be replaced by its canonical orthonormalization form and its internal state 
//                    is_const_array is set as true. In the already canonical form the same array can
//                    be reused to orthonormalize other given arrays.
    void orthonormalize(array &given_array);
//
//  restore_original_basis_of(): If the current array is a transformation and the given array is a 
//                               transformed one, this routine transforms back the given array into
//                               its original basis and keeps the transformation unchanged. The
//                               current internal state is_const_array must be true.
    void restore_original_basis_of(array &given_array);
//
//  build_identity_form(): To replace the content of the current array by its identity form (2D array only).
    void build_identity_form();
//
//  save_to(): To save the current array in the given file.
    void save_to(const std::string &filename);
//
//  open(): To read the current array from the given file.
    void open(const std::string &filename);
//
//
};
#endif
