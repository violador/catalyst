#include "molecular_system.hpp"
//
//
//
double molecular_system::electronic_energy()
{
    if(ab_initio_ready)
    {
        return wavefunction -> energy();
    }
    else
    {
        get_wavefunction(config -> wavefunction_type(task_number));
        ab_initio_ready = true;
        return wavefunction -> energy();
    }
}
