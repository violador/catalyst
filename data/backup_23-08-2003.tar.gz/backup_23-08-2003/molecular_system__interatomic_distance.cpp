#include "molecular_system.hpp"
//
//
//
double molecular_system::interatomic_distance(const unsigned int &first_atom, const unsigned int &second_atom)
{
    if(atom_positions_ready && (first_atom > 0) && (first_atom <= total_atoms) && (second_atom > 0) && (second_atom <= total_atoms))
    {
        return sqrt(gsl_pow_2(position_x.get(second_atom) - position_x.get(first_atom))
                  + gsl_pow_2(position_y.get(second_atom) - position_y.get(first_atom))
                  + gsl_pow_2(position_z.get(second_atom) - position_z.get(first_atom)));
    }
    else if(atom_positions_ready && (first_atom == second_atom))
    {
        return 0.0;
    }
    else
    {
        return 0.0;
    }
}
