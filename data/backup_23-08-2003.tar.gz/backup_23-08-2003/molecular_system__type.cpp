#include "molecular_system.hpp"
//
//
//
unsigned int molecular_system::type(const unsigned int &atom)
{
    return (atom_types_ready && (atom > 0) && (atom <= total_atoms)? atom_type.get(atom) : 0);
}
