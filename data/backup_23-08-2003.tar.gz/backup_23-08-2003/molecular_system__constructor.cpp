#include "molecular_system.hpp"
//
//
//
#ifndef USE_MPI
molecular_system::molecular_system(const std::string &input_filename, const unsigned int &given_task)
{
    settings runtime_setup;
    config = &runtime_setup;
    #pragma omp parallel sections
    {
        #pragma omp section
        {
            task_number = given_task;
            ab_initio_ready = false;
            system_com_ready = false;
            nuclear_repulsion_ready = false;
            system_name = input_filename;
        }
        #pragma omp section
        {
            total_atoms_ready = false;
            total_atoms = get_total_atoms(input_filename);
            atom_types_ready = false;
            atom_positions_ready = false;
            atom_velocities_ready = false;
            read_input_file(input_filename);
        }
    }
    report_input_reading();
}
#endif
//
//
//
molecular_system::molecular_system(const std::string &input_filename, settings &runtime_setup, const unsigned int &given_task)
{
    config = &runtime_setup;
    #pragma omp parallel sections
    {
        #pragma omp section
        {
            task_number = given_task;
            ab_initio_ready = false;
            system_com_ready = false;
            nuclear_repulsion_ready = false;
            system_name = input_filename;
        }
        #pragma omp section
        {
            total_atoms_ready = false;
            total_atoms = get_total_atoms(input_filename);
            atom_types_ready = false;
            atom_positions_ready = false;
            atom_velocities_ready = false;
            read_input_file(input_filename);
        }
    }
    report_input_reading();
}
