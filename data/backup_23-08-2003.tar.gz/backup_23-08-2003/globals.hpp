#ifndef __GLOBALS_HPP
#define __GLOBALS_HPP
//
// Defining some alias:
#define OS_TYPE              "GNU/Linux"    // The OS name.
#define LINUX                               // The OS type. 
#define CATALYST_VERSION     "experimental" // The current version of the catalyst.
#define COMPILATION_NUMBER   "experimental" // A random number to identify the compilation.
#define USER_CONFIG_FILENAME ".catalystrc"  // The name of the user's preferences file.
#define COMMENT_TAG          "#"            // Tag for comment lines in any input file.
#define AU_UNIT              "a.u."         // Tag for atomic unit reference.
#define EV_UNIT              "eV"           // Tag for electron volt unit reference.
#define ANG_UNIT             "A"            // Tag for angstron unit reference.
#define S_UNIT               "s"            // Tag for second unit reference.
#define FS_UNIT              "fs"           // Tag for femtosecond unit reference.
#define K_UNIT               "K"            // Tag for kelvin unit reference.
#define PROB_UNIT            "%"            // Tag for probabilty unit reference.
#define MAX_PRECISION        10             // Tag for the maximum numeric precision.
#define DEFAULT_NOT_DEFINED  "not defined"
#define DEFAULT_SCF_CRITERIA 0.00000001
#define DEFAULT_PRECISION    8
#define DEFAULT_TASK_NUMBER  1
#define ON_KEY_CONTROL       "on"
#define OFF_KEY_CONTROL      "off"
#define MASTER_PROCESS       0
#define EXIT_SUCCESS         0              // Tag for success operations.
#define EXIT_FAILURE         1              // Tag for fail operations.
//#define USE_MPI                             // To turn on the MPI region of the code.
//
// Including C standard libs:
#include <stdlib.h>
#include <math.h>
//
// Including C++ standard libs:
#include <iostream>
#include <iomanip>
#include <fstream>
#include <sstream>
#include <string>
#include <algorithm>
#include <cctype>
#include <ios>
#include <ctime>
//
// Including GSL libs:
#include <gsl/gsl_errno.h>
#include <gsl/gsl_math.h>
#include <gsl/gsl_vector.h>
#include <gsl/gsl_matrix.h>
#include <gsl/gsl_sf_exp.h>
#include <gsl/gsl_sf_erf.h>
#include <gsl/gsl_linalg.h>
#include <gsl/gsl_eigen.h>
#include <gsl/gsl_blas.h>
#include <gsl/gsl_const_num.h>
#include <gsl/gsl_const_mksa.h>
#include <gsl/gsl_rng.h>
//
// Including Boost C++ libs:
//#include <boost/filesystem.hpp>
//#include <boost/signals2.hpp>
#ifdef USE_MPI
  #include <boost/mpi.hpp>               //
  #include <boost/mpi/environment.hpp>   // ADVICE: To include the Boost C++ MPI libs means to add a 
  #include <boost/mpi/communicator.hpp>  //         huge amount of extra time in the compilation.
  #include <boost/mpi/nonblocking.hpp>
#endif
//#include <boost/serialization/string.hpp>
//#include <boost/serialization/base_object.hpp>
//
// Including Linux kernel libs:
#ifdef LINUX
  #include <sys/sysinfo.h>
  #include <unistd.h>
#endif
//
// Includind Windows kernel libs:
#ifdef WIN32
// Empty, so far.
#endif
//
// INcluding OSX kernel libs:
#ifdef OSX
// Empty, so far.
#endif
//
//
#endif
